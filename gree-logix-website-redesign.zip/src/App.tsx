import { useEffect, useRef } from "react";
import { gsap, ScrollTrigger } from "./lib/gsap";
import { builders, initMagnetic } from "./lib/builders";
import { initScroll, destroyScroll, getLenis } from "./lib/scroll";
import { STAGES, stage } from "./three/stage";
import Scene from "./three/Scene";
import { Loader, Nav, Toolbar, YouCursor } from "./components/Chrome";
import Hero from "./components/Hero";
import { MarqueeBand, Problems, Services } from "./components/Sections1";
import { Process, Work, Testimonials } from "./components/Sections2";
import { Deliver, Why, Blog, Faq, Contact, Footer } from "./components/Sections3";

export default function App() {
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const html = document.documentElement;
    const loader = document.querySelector<HTMLElement>("[data-loader]");

    if (reduce) {
      html.classList.add("no-build");
      loader?.remove();
      return;
    }

    window.scrollTo(0, 0);
    if ("scrollRestoration" in history) history.scrollRestoration = "manual";

    const lenis = initScroll();
    lenis.stop();
    builders.mount();
    const killMagnetic = initMagnetic();

    const ctx = gsap.context(() => {
      /* ---- 3D stage keyframes follow the sections ---- */
      const secs = gsap.utils.toArray<HTMLElement>("[data-stage]");
      let prev = { ...STAGES[secs[0].dataset.stage!] };
      Object.assign(stage, prev);
      secs.slice(1).forEach((sec) => {
        const to = { ...STAGES[sec.dataset.stage!] };
        gsap.fromTo(
          stage,
          { ...prev },
          {
            ...to,
            ease: "none",
            immediateRender: false,
            scrollTrigger: { trigger: sec, start: "top bottom", end: "top 25%", scrub: 1.2 },
          }
        );
        prev = to;
      });

      /* ---- every [data-build] element is placed by a cursor when it scrolls in ---- */
      gsap.utils.toArray<HTMLElement>("[data-build]:not([data-h])").forEach((el) => {
        ScrollTrigger.create({
          trigger: el,
          start: "top 90%",
          once: true,
          onEnter: () => builders.build(el),
        });
      });

      /* ---- count-ups ---- */
      gsap.utils.toArray<HTMLElement>("[data-count]").forEach((el) => {
        const target = Number(el.dataset.count);
        const suffix = el.dataset.suffix || "";
        const o = { v: 0 };
        ScrollTrigger.create({
          trigger: el,
          start: "top 92%",
          once: true,
          onEnter: () =>
            gsap.to(o, {
              v: target,
              duration: 2.4,
              delay: el.closest("#top") && window.scrollY < 50 ? 3.4 : 1.1,
              ease: "expo.out",
              onUpdate: () => (el.textContent = Math.round(o.v) + suffix),
            }),
        });
      });

      /* ---- toolbar: which frame are we in ---- */
      gsap.utils.toArray<HTMLElement>("[data-name]").forEach((el) => {
        ScrollTrigger.create({
          trigger: el,
          start: "top 55%",
          end: "bottom 55%",
          onToggle: (self) => {
            if (self.isActive) window.dispatchEvent(new CustomEvent("gl:section", { detail: el.dataset.name }));
          },
        });
      });

      /* ---- loader: the file "opens", then the collaborators join in ---- */
      const num = loader?.querySelector<HTMLElement>("[data-ld-num]");
      const bar = loader?.querySelector<HTMLElement>("[data-ld-bar]");
      const counter = { v: 0 };
      let finished = false;
      const finish = () => {
        if (finished) return;
        finished = true;
        loader?.remove();
        lenis.start();
        builders.start();
        ScrollTrigger.refresh();
      };
      const navEl = document.querySelector<HTMLElement>("[data-nav]");
      const avs = loader ? Array.from(loader.querySelectorAll("[data-ld-av]")) : [];
      gsap.set(navEl, { y: -80, opacity: 0 });
      const tl = gsap.timeline({ delay: 0.15 });
      tl.to(counter, {
        v: 100,
        duration: 1.6,
        ease: "power2.inOut",
        onUpdate: () => {
          if (num) num.textContent = String(Math.round(counter.v));
          if (bar) bar.style.transform = `scaleX(${counter.v / 100})`;
        },
      })
        .from(avs, { scale: 0, duration: 0.5, stagger: 0.12, ease: "back.out(3)" }, 0)
        .to(loader, { clipPath: "inset(0 0 100% 0)", duration: 1.1, ease: "expo.inOut" }, "+=0.15")
        .add(() => {
          lenis.start();
          builders.start();
        }, "-=0.55")
        .to(navEl, { y: 0, opacity: 1, duration: 1, ease: "expo.out" }, "-=0.4")
        .add(finish);
      window.setTimeout(finish, 7000);
    }, rootRef);

    const onLoad = () => ScrollTrigger.refresh();
    window.addEventListener("load", onLoad);
    document.fonts?.ready.then(() => ScrollTrigger.refresh());

    return () => {
      window.removeEventListener("load", onLoad);
      killMagnetic();
      ctx.revert();
      builders.destroy();
      destroyScroll();
      void getLenis;
    };
  }, []);

  return (
    <>
      <Scene />
      <div className="vignette" />
      <div className="grain" />
      <Loader />
      <Nav />
      <div ref={rootRef} className="relative z-10">
        <main>
          <Hero />
          <MarqueeBand />
          <Problems />
          <Services />
          <Process />
          <Work />
          <Testimonials />
          <Deliver />
          <Why />
          <Blog />
          <Faq />
          <Contact />
        </main>
        <Footer />
      </div>
      <Toolbar />
      <YouCursor />
    </>
  );
}
