import { useEffect, useRef, useState } from "react";
import { gsap, ScrollTrigger } from "../lib/gsap";
import { scrollToTarget } from "../lib/scroll";

const TEAM_COLORS = [
  ["A", "#7dff5c"],
  ["H", "#38e1ff"],
  ["S", "#ff5fa8"],
  ["B", "#ffb23e"],
  ["Z", "#a78bff"],
  ["Ab", "#ffe34d"],
];

export function Loader() {
  return (
    <div data-loader className="fixed inset-0 z-[100] flex flex-col justify-between bg-bg p-6 md:p-10" style={{ clipPath: "inset(0 0 0 0)" }}>
      <div className="flex items-start justify-between font-mono text-[11px] uppercase tracking-[0.2em] text-white/50">
        <span>greelogix.fig</span>
        <span className="flex items-center gap-2">
          <span className="pulse-dot size-2 rounded-full bg-lime" /> 6 collaborators joining
        </span>
      </div>
      <div className="relative">
        <div className="mb-6 flex -space-x-2">
          {TEAM_COLORS.map(([n, c]) => (
            <span
              key={n}
              data-ld-av
              className="grid size-9 place-items-center rounded-full border-2 border-bg text-[11px] font-bold text-bg"
              style={{ background: c }}
            >
              {n}
            </span>
          ))}
        </div>
        <div className="flex items-end justify-between">
          <div data-ld-num className="text-[clamp(6rem,24vw,22rem)] font-extrabold leading-[0.8] tracking-[-0.06em] tabular-nums">
            0
          </div>
          <div className="mb-3 hidden max-w-[16rem] text-right text-sm text-white/50 md:block">
            Opening the workspace.<br />Everything you see is about to be built — live.
          </div>
        </div>
        <div className="mt-8 h-px w-full bg-white/10">
          <div data-ld-bar className="h-full origin-left bg-lime" style={{ transform: "scaleX(0)" }} />
        </div>
      </div>
    </div>
  );
}

const links = [
  ["Services", "#services"],
  ["Process", "#process"],
  ["Work", "#work"],
  ["Stack", "#stack"],
  ["FAQ", "#faq"],
];

export function Nav() {
  const ref = useRef<HTMLElement>(null);

  useEffect(() => {
    let hidden = false;
    const st = ScrollTrigger.create({
      start: 0,
      end: "max",
      onUpdate: (self) => {
        const shouldHide = self.direction === 1 && self.scroll() > 240;
        if (shouldHide !== hidden) {
          hidden = shouldHide;
          gsap.to(ref.current, { yPercent: hidden ? -130 : 0, duration: 0.6, ease: "power3.out" });
        }
      },
    });
    return () => st.kill();
  }, []);

  return (
    <header ref={ref} data-nav className="fixed inset-x-0 top-0 z-50 px-4 pt-4 md:px-8 md:pt-5">
      <div className="mx-auto flex max-w-[1500px] items-center justify-between rounded-full border border-white/10 bg-[#070a08]/70 py-2.5 pl-5 pr-2.5 backdrop-blur-xl">
        <button onClick={() => scrollToTarget(0)} className="flex cursor-pointer items-center gap-2.5" aria-label="GreeLogix home">
          <svg width="26" height="26" viewBox="0 0 26 26" fill="none">
            <rect x="2" y="2" width="9" height="9" rx="2" fill="#7dff5c" />
            <rect x="13" y="2" width="9" height="9" rx="2" fill="#7dff5c" opacity=".55" />
            <rect x="2" y="13" width="9" height="9" rx="2" fill="#7dff5c" opacity=".55" />
            <rect x="13" y="13" width="9" height="9" rx="2" fill="#7dff5c" opacity=".25" />
          </svg>
          <span className="text-[19px] font-extrabold tracking-[-0.04em]">
            gree<span className="text-lime">logix</span>
          </span>
        </button>

        <nav className="hidden items-center gap-1 lg:flex">
          {links.map(([l, t]) => (
            <button
              key={l}
              onClick={() => scrollToTarget(t)}
              className="cursor-pointer rounded-full px-4 py-2 text-sm font-medium text-white/65 transition hover:bg-white/8 hover:text-white"
            >
              {l}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <div className="hidden items-center gap-2 md:flex">
            <div className="flex -space-x-1.5">
              {TEAM_COLORS.slice(0, 4).map(([n, c]) => (
                <span key={n} className="grid size-6 place-items-center rounded-full border-2 border-[#070a08] text-[9px] font-bold text-bg" style={{ background: c }}>
                  {n}
                </span>
              ))}
            </div>
            <span className="font-mono text-[10px] uppercase tracking-widest text-white/45">6 live</span>
          </div>
          <button
            data-magnetic
            onClick={() => scrollToTarget("#contact")}
            className="cursor-pointer rounded-full bg-lime px-5 py-2.5 text-sm font-bold text-bg transition hover:bg-white"
          >
            Book a call
          </button>
        </div>
      </div>
    </header>
  );
}

/** Figma-style toolbar showing which "frame" you're looking at */
export function Toolbar() {
  const [name, setName] = useState("Hero");
  const [pct, setPct] = useState(0);
  const [tool, setTool] = useState(0);

  useEffect(() => {
    const onSec = (e: Event) => setName((e as CustomEvent<string>).detail);
    window.addEventListener("gl:section", onSec);
    const st = ScrollTrigger.create({
      start: 0,
      end: "max",
      onUpdate: (s) => setPct(Math.round(s.progress * 100)),
    });
    const iv = window.setInterval(() => setTool((t) => (t + 1) % 4), 2400);
    return () => {
      window.removeEventListener("gl:section", onSec);
      st.kill();
      clearInterval(iv);
    };
  }, []);

  const icons = [
    <path key="a" d="M5 3l14 7-6 2-2 6z" />,
    <g key="b"><rect x="4" y="4" width="16" height="16" rx="1" /><path d="M4 9h16M9 4v16" /></g>,
    <path key="c" d="M5 6V4h14v2M12 4v16M9 20h6" />,
    <path key="d" d="M4 20l4-1L19 8l-3-3L5 16z" />,
  ];

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-5 z-50 hidden justify-center md:flex">
      <div className="flex items-center gap-1 rounded-2xl border border-white/10 bg-[#070a08]/80 p-1.5 pr-4 backdrop-blur-xl">
        {icons.map((ic, i) => (
          <span
            key={i}
            className={"grid size-9 place-items-center rounded-xl transition " + (tool === i ? "bg-lime text-bg" : "text-white/50")}
          >
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" strokeLinecap="round">
              {ic}
            </svg>
          </span>
        ))}
        <span className="mx-2 h-5 w-px bg-white/15" />
        <span className="w-28 font-mono text-[11px] uppercase tracking-[0.14em] text-white/80">{name}</span>
        <span className="font-mono text-[11px] tabular-nums text-lime">{String(pct).padStart(3, "0")}%</span>
      </div>
    </div>
  );
}

/** A small ring that follows the visitor — they're one of the collaborators too */
export function YouCursor() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current!;
    const xTo = gsap.quickTo(el, "x", { duration: 0.35, ease: "power3.out" });
    const yTo = gsap.quickTo(el, "y", { duration: 0.35, ease: "power3.out" });
    const move = (e: PointerEvent) => {
      xTo(e.clientX);
      yTo(e.clientY);
      const hot = (e.target as HTMLElement)?.closest("a,button,[data-hover],input,select,textarea,summary");
      gsap.to(el.firstElementChild, { scale: hot ? 1.9 : 1, duration: 0.4, ease: "power3.out", overwrite: "auto" });
      gsap.to(el.lastElementChild, { opacity: hot ? 1 : 0, duration: 0.3, overwrite: "auto" });
    };
    window.addEventListener("pointermove", move);
    return () => window.removeEventListener("pointermove", move);
  }, []);
  return (
    <div ref={ref} className="you-cursor pointer-events-none fixed left-0 top-0 z-[91]">
      <div className="-ml-4 -mt-4 size-8 rounded-full border border-lime/70" />
      <span className="absolute left-4 top-4 rounded bg-white px-1.5 py-0.5 font-mono text-[9px] font-semibold uppercase tracking-wider text-bg opacity-0">You</span>
    </div>
  );
}
