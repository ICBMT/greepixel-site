import { Words, Arrow } from "./ui";
import { scrollToTarget } from "../lib/scroll";

const stats = [
  { v: "150", s: "+", l: "Products Shipped" },
  { v: "75", s: "+", l: "AI Systems Built" },
  { v: null, t: "4–8", l: "Weeks · Typical MVP" },
  { v: "5", s: "+", l: "Countries Served" },
];

export default function Hero() {
  return (
    <section id="top" data-stage="hero" data-name="Hero" className="relative flex min-h-[100svh] flex-col justify-end px-5 pb-8 pt-36 md:px-10">
      <div className="mx-auto grid w-full max-w-[1500px] gap-10 lg:grid-cols-12">
        <div className="lg:col-span-8">
          <div
            data-build="draw"
            data-label="Badge"
            className="inline-flex items-center gap-2.5 rounded-full border border-white/15 bg-[#0a100b]/80 px-4 py-2 font-mono text-[11px] uppercase tracking-[0.16em] text-white/75"
          >
            <span className="pulse-dot size-2 rounded-full bg-lime" />
            AI &amp; Custom Software · 150+ products shipped
          </div>

          <h1
            data-build="text"
            data-label="H1"
            className="mt-7 text-[clamp(3.1rem,10.4vw,10.6rem)] font-extrabold leading-[0.86] tracking-[-0.05em]"
          >
            <Words text="We build AI software" />
            <br />
            <Words text="that *actually ships.*" />
          </h1>

          <p
            data-build="text"
            data-label="Paragraph"
            className="mt-8 max-w-xl text-lg leading-relaxed text-white/70 md:text-xl"
          >
            <Words text="A senior software agency for startups, SMEs and nonprofits who need AI products, custom web & mobile apps and QA — delivered in weeks, not quarters. No junior hand-offs. No endless discovery." />
          </p>

          <div data-build="draw" data-label="CTA group" className="mt-9 flex flex-wrap items-center gap-3">
            <button data-magnetic onClick={() => scrollToTarget("#contact")} className="btn btn-lime">
              Book a free 30-min call <Arrow />
            </button>
            <button data-magnetic onClick={() => scrollToTarget("#work")} className="btn btn-ghost">
              See our work
            </button>
          </div>
        </div>

        <div className="flex items-end lg:col-span-4 lg:justify-end">
          <div
            data-build="drag"
            data-label="Card"
            className="glass relative w-full max-w-sm p-6"
          >
            <div className="font-mono text-[10px] uppercase tracking-[0.2em] text-lime">Free AI Audit · 5 questions</div>
            <h3 className="mt-3 text-2xl font-bold leading-tight tracking-[-0.03em]">Planning an AI product, SaaS or MVP?</h3>
            <p className="mt-2 text-sm leading-relaxed text-white/60">
              Check your launch readiness — calculate risk, QA gaps and production scope with senior engineers.
            </p>
            <button onClick={() => scrollToTarget("#contact")} className="mt-5 inline-flex cursor-pointer items-center gap-2 text-sm font-bold text-lime">
              Take the free audit <Arrow />
            </button>
          </div>
        </div>
      </div>

      <div data-build="draw" data-label="Stats" className="mx-auto mt-14 grid w-full max-w-[1500px] grid-cols-2 gap-y-6 border-t border-white/15 pt-6 md:grid-cols-4">
        {stats.map((s) => (
          <div key={s.l} data-item>
            <div className="text-4xl font-extrabold tracking-[-0.04em] md:text-6xl">
              {s.v ? (
                <>
                  <span data-count={s.v} data-suffix={s.s}>0</span>
                </>
              ) : (
                s.t
              )}
            </div>
            <div className="mt-1 font-mono text-[11px] uppercase tracking-[0.16em] text-white/50">{s.l}</div>
          </div>
        ))}
      </div>
    </section>
  );
}
