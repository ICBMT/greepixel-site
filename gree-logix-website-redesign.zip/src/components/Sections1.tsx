import { useEffect, useRef } from "react";
import { gsap, ScrollTrigger } from "../lib/gsap";
import { getLenis, scrollToTarget } from "../lib/scroll";
import { builders } from "../lib/builders";
import { problems, services } from "../data";
import { SectionHead, Arrow, Chip, Words } from "./ui";

/* ------------------------------------------------------------------ */
/* Marquee – speeds up & flips with scroll velocity                    */
/* ------------------------------------------------------------------ */
const words = ["AI Products", "MVPs", "Laravel", "Flutter", "React", "QA", "Node.js", "OpenAI"];

function Row({ outline }: { outline?: boolean }) {
  const item = (k: string) => (
    <div key={k} className="mq-item">
      {words.map((w, i) => (
        <span key={w} className="flex items-center gap-[2.2rem]">
          <span className={"text-[clamp(3.5rem,10vw,9rem)] font-extrabold uppercase leading-none tracking-[-0.04em] " + ((i + (outline ? 1 : 0)) % 2 ? "stroke" : "")}>
            {w}
          </span>
          <svg width="40" height="40" viewBox="0 0 26 26" className="shrink-0 text-lime">
            <rect x="3" y="3" width="20" height="20" rx="4" fill="currentColor" />
          </svg>
        </span>
      ))}
    </div>
  );
  return (
    <div className="mq-row">
      {item("a")}
      {item("b")}
    </div>
  );
}

export function MarqueeBand() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const rows = ref.current!.querySelectorAll<HTMLElement>(".mq-row");
    const ctx = gsap.context(() => {
      const tls = Array.from(rows).map((row, i) =>
        gsap.fromTo(row, { xPercent: i % 2 ? -50 : 0 }, { xPercent: i % 2 ? 0 : -50, ease: "none", duration: 38, repeat: -1 })
      );
      const tick = () => {
        const v = getLenis()?.velocity ?? 0;
        const boost = 1 + Math.min(Math.abs(v) * 0.35, 9);
        tls.forEach((tl) => {
          const ts = gsap.utils.interpolate(tl.timeScale(), boost, 0.08);
          tl.timeScale(ts);
        });
      };
      gsap.ticker.add(tick);
      return () => gsap.ticker.remove(tick);
    }, ref);
    return () => ctx.revert();
  }, []);

  return (
    <div ref={ref} className="relative -mt-4 overflow-hidden border-y border-white/10 bg-bg/70 py-8 backdrop-blur-sm">
      <div className="space-y-4">
        <Row />
        <Row outline />
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Problems                                                            */
/* ------------------------------------------------------------------ */
export function Problems() {
  return (
    <section data-stage="problems" data-name="Problems" className="relative px-5 py-36 md:px-10">
      <div className="mx-auto max-w-[1500px]">
        <SectionHead
          kicker="Problems we solve"
          title="Sound familiar? We fix this *every week.*"
          sub="Startups, SMEs, nonprofits and international teams come to GreeLogix when software is blocking revenue, fundraising or operations — not when they need another slide deck."
        />
        <div className="mt-20 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
          {problems.map((p, i) => (
            <article key={p.t} data-build="drag" data-label={`Issue-${String(i + 1).padStart(2, "0")}`} className="glass group flex min-h-[290px] flex-col p-7">
              <div className="flex items-center justify-between font-mono text-[11px] uppercase tracking-[0.18em] text-white/40">
                <span>Issue-{String(i + 1).padStart(2, "0")}</span>
                <span className="size-2 rounded-full bg-[#ff5f57]" />
              </div>
              <h3 className="mt-8 text-[1.65rem] font-bold leading-[1.05] tracking-[-0.03em]">{p.t}</h3>
              <p className="mt-4 flex-1 text-[15px] leading-relaxed text-white/55">{p.d}</p>
              <button onClick={() => scrollToTarget("#contact")} className="mt-6 inline-flex cursor-pointer items-center gap-2 self-start text-sm font-bold text-lime">
                {p.l} <Arrow className="transition-transform duration-300 group-hover:translate-x-1 group-hover:-translate-y-1" />
              </button>
            </article>
          ))}
          <article data-build="drag" data-label="CTA" className="relative flex min-h-[290px] flex-col justify-between overflow-hidden rounded-3xl bg-lime p-7 text-bg">
            <div className="font-mono text-[11px] font-semibold uppercase tracking-[0.18em]">Resolved ✓</div>
            <div>
              <h3 className="text-[2rem] font-extrabold leading-[0.98] tracking-[-0.04em]">Get your free readiness audit.</h3>
              <button onClick={() => scrollToTarget("#contact")} className="mt-6 inline-flex cursor-pointer items-center gap-2 rounded-full bg-bg px-5 py-3 text-sm font-bold text-lime">
                Start now <Arrow />
              </button>
            </div>
          </article>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Services – pinned horizontal scroll                                  */
/* ------------------------------------------------------------------ */
export function Services() {
  const reduced = typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const secRef = useRef<HTMLElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const barRef = useRef<HTMLDivElement>(null);
  const cntRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const sec = secRef.current!;
    const track = trackRef.current!;
    const ctx = gsap.context(() => {
      const dist = () => Math.max(0, track.scrollWidth - window.innerWidth);
      const tween = gsap.to(track, {
        x: () => -dist(),
        ease: "none",
        scrollTrigger: {
          trigger: sec,
          start: "top top",
          end: () => "+=" + dist(),
          pin: true,
          scrub: 1,
          invalidateOnRefresh: true,
          anticipatePin: 1,
          onUpdate: (self) => {
            if (barRef.current) barRef.current.style.transform = `scaleX(${self.progress})`;
            if (cntRef.current) cntRef.current.textContent = String(Math.min(services.length, Math.floor(self.progress * services.length) + 1)).padStart(2, "0");
          },
        },
      });

      track.querySelectorAll<HTMLElement>("[data-h]").forEach((el) => {
        const left = el.getBoundingClientRect().left;
        if (left < window.innerWidth * 0.9) {
          ScrollTrigger.create({ trigger: sec, start: "top 62%", once: true, onEnter: () => builders.build(el) });
        } else {
          ScrollTrigger.create({
            trigger: el,
            containerAnimation: tween,
            start: "left 92%",
            once: true,
            onEnter: () => builders.build(el),
          });
        }
      });
    }, sec);
    return () => ctx.revert();
  }, []);

  return (
    <section ref={secRef} id="services" data-stage="services" data-name="Services" className={"relative " + (reduced ? "overflow-x-auto py-24" : "h-screen overflow-hidden")}>
      <div ref={trackRef} className="flex h-full w-max items-center gap-6 px-5 md:gap-8 md:px-10">
        <div className="flex w-[min(88vw,760px)] shrink-0 flex-col justify-center pr-6 md:pr-16">
          <Chip h>What we build</Chip>
          <h2 data-build="text" data-h data-label="H2" className="mt-6 text-[clamp(2.6rem,7vw,6.6rem)] font-extrabold leading-[0.92] tracking-[-0.045em]">
            <Words text="AI & custom software *built to ship.*" />
          </h2>
          <p data-build="text" data-h data-label="Paragraph" className="mt-6 max-w-xl text-lg leading-relaxed text-white/60">
            <Words text="One senior team for AI products, web & mobile apps, MVPs, and the QA that gets them production-ready — for founders and operators in the US, UK, UAE, Australia and Canada." />
          </p>
          <div className="mt-8 flex items-center gap-3 font-mono text-[11px] uppercase tracking-[0.2em] text-white/45">
            Keep scrolling <span className="inline-block animate-pulse text-lime">→</span>
          </div>
        </div>

        {services.map((s, i) => (
          <article
            key={s.t}
            data-build="drag"
            data-h
            data-label={`Service-${String(i + 1).padStart(2, "0")}`}
            className="glass flex h-[min(72vh,600px)] w-[min(82vw,430px)] shrink-0 flex-col p-5"
          >
            <div className="viz h-[42%] shrink-0" style={{ ["--vh" as string]: s.h, ["--vx" as string]: `${20 + (i * 13) % 60}%`, ["--vy" as string]: `${30 + (i * 17) % 40}%` }}>
              <span className="absolute bottom-2 left-4 z-10 text-[5.5rem] font-extrabold leading-none tracking-[-0.06em] stroke">
                {String(i + 1).padStart(2, "0")}
              </span>
            </div>
            <h3 className="mt-6 text-[1.9rem] font-bold leading-[1.02] tracking-[-0.035em]">{s.t}</h3>
            <p className="mt-3 flex-1 text-[15px] leading-relaxed text-white/55">{s.d}</p>
            <div className="mt-4 flex flex-wrap gap-2">
              {s.tags.map((t) => (
                <span key={t} className="rounded-full border border-white/15 px-3 py-1 font-mono text-[11px] text-white/70">
                  {t}
                </span>
              ))}
            </div>
          </article>
        ))}
        <div className="w-[12vw] shrink-0" />
      </div>

      <div className="absolute inset-x-5 bottom-20 flex items-center gap-4 md:inset-x-10 md:bottom-24">
        <span className="font-mono text-[11px] tracking-widest text-lime">
          <span ref={cntRef}>01</span> / {String(services.length).padStart(2, "0")}
        </span>
        <div className="h-px flex-1 bg-white/15">
          <div ref={barRef} className="h-full origin-left bg-lime" style={{ transform: "scaleX(0)" }} />
        </div>
      </div>
    </section>
  );
}
