import { useEffect, useRef } from "react";
import { gsap } from "../lib/gsap";
import { steps, portfolio, quotes } from "../data";
import { SectionHead, Arrow, Chip, Words } from "./ui";

/* ------------------------------------------------------------------ */
/* Process – stacking sticky cards                                      */
/* ------------------------------------------------------------------ */
function StepVisual({ i }: { i: number }) {
  if (i === 0)
    return (
      <div className="space-y-3 p-6">
        {[
          ["You", "We need an AI MVP live before our seed round."],
          ["GreeLogix", "Got it. Stack, timeline and budget in 30 min?"],
          ["You", "Perfect. Booking now."],
        ].map(([w, m], k) => (
          <div key={k} className={"flex " + (w === "You" ? "justify-start" : "justify-end")}>
            <div className={"max-w-[85%] rounded-2xl px-4 py-3 text-sm " + (w === "You" ? "bg-white/10" : "bg-lime text-bg")}>
              <div className="mb-1 font-mono text-[9px] uppercase tracking-widest opacity-60">{w}</div>
              {m}
            </div>
          </div>
        ))}
      </div>
    );
  if (i === 1)
    return (
      <div className="space-y-3.5 p-6 font-mono text-[11px] text-white/70">
        {[["Discovery", 14, 0], ["Design system", 28, 14], ["Core build", 62, 30], ["QA + launch", 36, 64]].map(([l, w, o]) => (
          <div key={l as string}>
            <div className="mb-1.5 flex justify-between"><span>{l}</span><span className="text-lime">wk {Number(o) / 14 + 1 | 0}</span></div>
            <div className="h-2.5 rounded-full bg-white/10"><div className="h-full rounded-full bg-lime/80" style={{ width: `${w}%`, marginLeft: `${o}%` }} /></div>
          </div>
        ))}
      </div>
    );
  if (i === 2)
    return (
      <div className="grid grid-cols-7 gap-1.5 p-6">
        {Array.from({ length: 28 }).map((_, k) => (
          <div key={k} className="aspect-square rounded-md" style={{ background: `rgba(125,255,92,${[0.08, 0.2, 0.45, 0.75, 1][(k * 7 + (k % 5)) % 5]})` }} />
        ))}
        <div className="col-span-7 mt-3 font-mono text-[11px] uppercase tracking-widest text-white/50">Weekly demo · every Friday</div>
      </div>
    );
  return (
    <div className="space-y-2.5 p-6 text-sm">
      {["Deployed to production", "QA sign-off complete", "Documentation handed over", "90 days free support"].map((t) => (
        <div key={t} className="flex items-center gap-3 rounded-xl bg-white/5 px-4 py-3">
          <span className="grid size-5 place-items-center rounded-full bg-lime text-[11px] font-bold text-bg">✓</span>
          {t}
        </div>
      ))}
    </div>
  );
}

export function Process() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const ctx = gsap.context(() => {
      const wraps = gsap.utils.toArray<HTMLElement>("[data-step]");
      wraps.forEach((w, i) => {
        const next = wraps[i + 1];
        if (!next) return;
        gsap.to(w.querySelector("[data-inner]"), {
          scale: 0.92,
          opacity: 0.45,
          ease: "none",
          scrollTrigger: { trigger: next, start: "top 78%", end: "top 20%", scrub: true },
        });
      });
    }, ref);
    return () => ctx.revert();
  }, []);

  return (
    <section id="process" data-stage="process" data-name="Process" className="relative px-5 py-36 md:px-10">
      <div className="mx-auto max-w-[1500px]">
        <SectionHead kicker="How we work" title="From first call to production in *weeks.*" sub="No black-box development. You see progress every sprint, talk to the engineers building your product, and know exactly what's shipping next." />
        <div ref={ref} className="mt-20">
          {steps.map((s, i) => (
            <div key={s.n} data-step className="sticky" style={{ top: `calc(13vh + ${i * 22}px)`, paddingBottom: i === steps.length - 1 ? 0 : "14vh" }}>
              <div data-build="draw" data-label={`Step ${s.n}`}>
                <div data-inner className="glass grid overflow-hidden md:grid-cols-12" style={{ minHeight: "min(52vh, 440px)" }}>
                  <div className="flex flex-col justify-between p-7 md:col-span-7 md:p-10">
                    <div className="text-[clamp(5rem,13vw,11rem)] font-extrabold leading-[0.8] tracking-[-0.06em] stroke">{s.n}</div>
                    <div>
                      <h3 className="mt-8 text-[clamp(2rem,4vw,3.4rem)] font-extrabold leading-none tracking-[-0.04em]">{s.t}</h3>
                      <p className="mt-4 max-w-lg text-base leading-relaxed text-white/60 md:text-lg">{s.d}</p>
                    </div>
                  </div>
                  <div className="border-t border-white/10 bg-black/30 md:col-span-5 md:flex md:items-center md:border-l md:border-t-0">
                    <div className="w-full"><StepVisual i={i} /></div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Work                                                                 */
/* ------------------------------------------------------------------ */
function Mock({ c, i }: { c: string; i: number }) {
  return (
    <div className="relative h-52 overflow-hidden rounded-2xl border border-white/10 bg-[#0a100b]">
      <div className="flex items-center gap-1.5 border-b border-white/10 px-3 py-2.5">
        <span className="size-2 rounded-full bg-[#ff5f57]" />
        <span className="size-2 rounded-full bg-[#febc2e]" />
        <span className="size-2 rounded-full bg-[#28c840]" />
        <span className="ml-3 h-3.5 flex-1 rounded-full bg-white/5" />
      </div>
      <div className="grid grid-cols-5 gap-2 p-3">
        <div className="col-span-1 space-y-2">
          {[1, 2, 3, 4].map((k) => <div key={k} className="h-3 rounded bg-white/10" />)}
        </div>
        <div className="col-span-4 space-y-2">
          <div className="grid grid-cols-3 gap-2">
            {[0, 1, 2].map((k) => (
              <div key={k} className="h-12 rounded-lg" style={{ background: k === i % 3 ? c : "rgba(255,255,255,.07)", opacity: k === i % 3 ? 0.9 : 1 }} />
            ))}
          </div>
          <div className="flex h-20 items-end gap-1.5 rounded-lg bg-white/5 p-2">
            {[40, 65, 35, 80, 55, 90, 60, 75].map((h, k) => (
              <div key={k} className="flex-1 rounded-t" style={{ height: `${h}%`, background: c, opacity: 0.35 + (k % 4) * 0.2 }} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export function Work() {
  return (
    <section id="work" data-stage="work" data-name="Case studies" className="relative px-5 py-36 md:px-10">
      <div className="mx-auto max-w-[1500px]">
        <SectionHead kicker="Case study" title="Real outcomes, not *agency fluff.*" />

        <div data-build="draw" data-label="Case study" className="glass mt-16 overflow-hidden">
          <div className="grid lg:grid-cols-2">
            <div className="p-8 md:p-12">
              <div className="font-mono text-[11px] uppercase tracking-[0.2em] text-lime">🎓 EdTech platform rescue &amp; re-launch</div>
              <h3 className="mt-6 text-[clamp(1.9rem,3.6vw,3.2rem)] font-extrabold leading-[1] tracking-[-0.04em]">
                Rescuing a stalled EdTech platform: how we shipped what 70 engineers couldn&apos;t.
              </h3>
              <p className="mt-5 max-w-xl text-base leading-relaxed text-white/60 md:text-lg">
                An education platform stuck in development limbo with a previous vendor of 70+ engineers — we took it over, stabilised the codebase, shipped the core student/teacher experience, and made the client happy.
              </p>
            </div>
            <div className="grid grid-cols-1 border-t border-white/10 lg:border-l lg:border-t-0">
              {[
                ["Dead → Live", "Project rescued and shipped to production"],
                ["3", "Platforms stabilised"],
                ["70+", "Engineers replaced by a small senior team"],
              ].map(([v, l], i) => (
                <div key={l} data-item className={"flex items-center justify-between gap-6 px-8 py-7 md:px-12 " + (i ? "border-t border-white/10" : "")}>
                  <div className="text-[clamp(2.2rem,4.4vw,4rem)] font-extrabold leading-none tracking-[-0.05em] text-lime">{v}</div>
                  <div className="max-w-[14rem] text-right text-sm text-white/55">{l}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-24 flex flex-wrap items-end justify-between gap-6">
          <div>
            <Chip>Portfolio highlights</Chip>
            <p data-build="text" data-label="Paragraph" className="mt-5 max-w-xl text-lg text-white/60">
              <Words text="SaaS, AI chatbots, mobile apps and internal tools — built for startups, SMEs and nonprofits." />
            </p>
          </div>
          <div data-build="draw" data-label="Link">
            <a href="https://greelogix.com/portfolio/" target="_blank" rel="noreferrer" className="btn btn-ghost">
              View all 150+ projects <Arrow />
            </a>
          </div>
        </div>

        <div className="mt-10 grid gap-5 lg:grid-cols-3">
          {portfolio.map((p, i) => (
            <article key={p.n} data-build="drag" data-label={p.n} className="glass p-4">
              <Mock c={p.c} i={i} />
              <div className="px-2 pb-3 pt-6">
                <div className="font-mono text-[11px] uppercase tracking-[0.16em]" style={{ color: p.c }}>{p.k}</div>
                <h4 className="mt-2 text-3xl font-extrabold tracking-[-0.04em]">{p.n}</h4>
                <p className="mt-3 text-[15px] leading-relaxed text-white/55">{p.d}</p>
                <div className="mt-5 flex flex-wrap gap-2">
                  {p.tags.map((t) => (
                    <span key={t} className="rounded-full border border-white/15 px-3 py-1 font-mono text-[11px] text-white/70">{t}</span>
                  ))}
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

export function Testimonials() {
  return (
    <section className="relative px-5 pb-36 md:px-10" data-name="Feedback">
      <div className="mx-auto max-w-[1500px]">
        <SectionHead kicker="Client feedback" title="Trusted by founders *worldwide.*" />
        <div className="mt-16 grid gap-5 lg:grid-cols-3">
          {quotes.map((q, i) => (
            <figure key={q.q} data-build="drag" data-label="Quote" className={"glass flex flex-col justify-between p-8 " + (i === 1 ? "lg:mt-12" : "")}>
              <div className="font-serif text-7xl italic leading-none text-lime">“</div>
              <blockquote className="mt-2 text-xl font-medium leading-snug tracking-[-0.02em] md:text-[1.45rem]">{q.q}</blockquote>
              <figcaption className="mt-8 flex items-center gap-3 border-t border-white/10 pt-5">
                <span className="grid size-10 place-items-center rounded-full bg-lime text-sm font-extrabold text-bg">{q.w[0]}</span>
                <div>
                  <div className="text-sm font-bold">{q.w}</div>
                  <div className="font-mono text-[10px] uppercase tracking-widest text-white/45">{q.r}</div>
                </div>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}
