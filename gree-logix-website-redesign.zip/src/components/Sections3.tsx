import { useState } from "react";
import { deliverables, stack, whyPoints, pillars, posts, faqs } from "../data";
import { SectionHead, Arrow, Chip, Words } from "./ui";

export function Deliver() {
  return (
    <section id="stack" data-stage="stack" data-name="Deliverables" className="relative px-5 py-36 md:px-10">
      <div className="mx-auto max-w-[1500px]">
        <div className="grid gap-16 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <div className="lg:sticky lg:top-32">
              <SectionHead kicker="What you receive" title="Everything you need to *own it.*" sub="Every engagement includes comprehensive deliverables to ensure transparency and quality." />
              <div data-build="draw" data-label="Guarantees" className="mt-10 grid grid-cols-3 gap-3">
                {[["100%", "Code ownership"], ["Full", "Documentation"], ["90 days", "Free support"]].map(([v, l]) => (
                  <div key={l} data-item className="glass p-5">
                    <div className="text-2xl font-extrabold tracking-[-0.04em] text-lime md:text-3xl">{v}</div>
                    <div className="mt-1 font-mono text-[10px] uppercase tracking-widest text-white/50">{l}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div className="space-y-4 lg:col-span-7">
            {deliverables.map((d, i) => (
              <div key={d.t} data-build="draw" data-label={`Deliverable ${i + 1}`}>
                <div className="glass group flex gap-6 p-7 md:p-8">
                  <div className="font-mono text-sm text-lime">0{i + 1}</div>
                  <div>
                    <h3 className="text-2xl font-bold tracking-[-0.03em] md:text-3xl">{d.t}</h3>
                    <p className="mt-2 max-w-lg text-[15px] leading-relaxed text-white/55">{d.d}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-40">
          <SectionHead kicker="Technologies" title="Our tech stack, *chosen for you.*" sub="Laravel, Flutter, React, Node.js, OpenAI and the QA stack to ship them safely — chosen for your product, not our preferences." center />
          <div data-build="draw" data-pop data-label="Tech stack" className="mx-auto mt-14 flex max-w-5xl flex-wrap justify-center gap-3">
            {stack.map(([n, c]) => (
              <div key={n} data-item className="glass flex items-center gap-3 !rounded-full py-3 pl-5 pr-6">
                <span className="size-2 rounded-full bg-lime" />
                <span className="text-base font-bold tracking-[-0.02em]">{n}</span>
                <span className="font-mono text-[10px] uppercase tracking-widest text-white/40">{c}</span>
              </div>
            ))}
          </div>
          <div data-build="draw" data-label="Counters" className="mx-auto mt-20 grid max-w-5xl grid-cols-2 gap-y-8 border-t border-white/15 pt-10 md:grid-cols-4">
            {[["150", "Products shipped"], ["75", "AI systems built"], ["90", "Happy clients"], ["20", "Core technologies"]].map(([v, l]) => (
              <div key={l} data-item className="text-center">
                <div className="text-5xl font-extrabold tracking-[-0.05em] md:text-7xl"><span data-count={v} data-suffix="+">0</span></div>
                <div className="mt-2 font-mono text-[11px] uppercase tracking-[0.16em] text-white/50">{l}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

export function Why() {
  return (
    <section data-stage="why" data-name="Why us" className="relative px-5 py-36 md:px-10">
      <div className="mx-auto max-w-[1500px]">
        <div className="grid gap-16 lg:grid-cols-2">
          <div>
            <SectionHead kicker="Why us" title="Why choose *GreeLogix?*" sub="Most agencies sell hours. We sell shipped software — with the proof to back it up on Upwork, Fiverr and Clutch, and 150+ products in production." />
            <ul className="mt-10 space-y-3">
              {whyPoints.map((p) => (
                <li key={p} data-build="draw" data-label="Proof" className="flex items-start gap-4 border-b border-white/10 pb-3 text-lg text-white/80">
                  <span className="mt-1 grid size-5 shrink-0 place-items-center rounded-full bg-lime text-[11px] font-bold text-bg">✓</span>
                  {p}
                </li>
              ))}
            </ul>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            {pillars.map((p, i) => (
              <article key={p.t} data-build="drag" data-label="Pillar" className={"glass flex flex-col justify-between p-7 " + (i % 2 ? "sm:mt-10" : "")} style={{ minHeight: 280 }}>
                <div className="font-mono text-[11px] text-lime">0{i + 1}</div>
                <div>
                  <h3 className="text-2xl font-bold leading-tight tracking-[-0.03em]">{p.t}</h3>
                  <p className="mt-3 text-[15px] leading-relaxed text-white/55">{p.d}</p>
                </div>
              </article>
            ))}
          </div>
        </div>

        <div data-build="draw" data-label="Platforms" className="mt-24 grid gap-4 md:grid-cols-3">
          {[["Upwork", "Top-rated agency"], ["Fiverr", "5.0 ★ rating"], ["Clutch", "Verified reviews"]].map(([n, l]) => (
            <div key={n} data-item className="glass flex items-center justify-between p-7">
              <div className="text-3xl font-extrabold tracking-[-0.04em]">{n}</div>
              <div className="font-mono text-[11px] uppercase tracking-widest text-lime">{l}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function Blog() {
  return (
    <section data-stage="why" data-name="Insights" className="relative px-5 pb-36 md:px-10">
      <div className="mx-auto max-w-[1500px]">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SectionHead kicker="Insights" title="Latest from the *blog.*" sub="Practical guides on AI automation, MVP delivery, QA and hiring developers — written by engineers who ship." />
          <div data-build="draw" data-label="Link">
            <a href="https://greelogix.com/blog/" target="_blank" rel="noreferrer" className="btn btn-ghost">
              Read all articles <Arrow />
            </a>
          </div>
        </div>
        <div className="mt-16 grid gap-5 lg:grid-cols-3">
          {posts.map((p) => (
            <article key={p.t} data-build="drag" data-label="Article" className="glass group flex flex-col overflow-hidden">
              <div className="viz h-44 rounded-none" style={{ ["--vh" as string]: p.h }} />
              <div className="flex flex-1 flex-col p-7">
                <div className="font-mono text-[11px] uppercase tracking-[0.14em] text-lime">{p.c}</div>
                <h3 className="mt-4 text-xl font-bold leading-snug tracking-[-0.025em]">{p.t}</h3>
                <p className="mt-3 flex-1 text-[15px] leading-relaxed text-white/55">{p.d}</p>
                <div className="mt-6 inline-flex items-center gap-2 text-sm font-bold">
                  Read article <Arrow className="transition-transform duration-300 group-hover:translate-x-1 group-hover:-translate-y-1" />
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

export function Faq() {
  const [open, setOpen] = useState(0);
  return (
    <section id="faq" data-stage="why" data-name="FAQ" className="relative px-5 pb-36 md:px-10">
      <div className="mx-auto grid max-w-[1500px] gap-16 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <SectionHead kicker="FAQ" title="Questions before *you book.*" sub="Straight answers — so you know what you're getting before the first call." />
        </div>
        <div className="lg:col-span-7">
          {faqs.map((f, i) => (
            <div key={f.q} data-build="draw" data-label="FAQ">
              <div className={"border-b border-white/15 " + (open === i ? "faq-open" : "")}>
                <button onClick={() => setOpen(open === i ? -1 : i)} className="flex w-full cursor-pointer items-center justify-between gap-6 py-6 text-left">
                  <span className="text-xl font-bold tracking-[-0.025em] md:text-2xl">{f.q}</span>
                  <span className={"grid size-9 shrink-0 place-items-center rounded-full border border-white/20 text-xl transition-all duration-500 " + (open === i ? "rotate-45 border-lime bg-lime text-bg" : "")}>+</span>
                </button>
                <div className="faq-body">
                  <div>
                    <p className="max-w-2xl pb-6 text-base leading-relaxed text-white/60">{f.a}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function Contact() {
  const [sent, setSent] = useState(false);
  return (
    <section id="contact" data-stage="contact" data-name="Contact" className="relative px-5 pb-24 pt-20 md:px-10">
      <div className="mx-auto max-w-[1500px]">
        <div className="text-center">
          <div className="flex justify-center"><Chip>Next step</Chip></div>
          <h2 data-build="text" data-label="H2" className="mx-auto mt-8 max-w-6xl text-[clamp(2.8rem,9vw,9rem)] font-extrabold leading-[0.88] tracking-[-0.05em]">
            <Words text="Let's build it *together.*" />
          </h2>
          <p data-build="text" data-label="Paragraph" className="mx-auto mt-8 max-w-xl text-lg text-white/65 md:text-xl">
            <Words text="Scope, timeline and cost range in 30 minutes — no sales deck. Or start with the free readiness quiz if you're still evaluating your stack." />
          </p>
        </div>

        <div className="mt-20 grid gap-5 lg:grid-cols-12">
          <div data-build="drag" data-label="Book a call" className="glass flex flex-col justify-between p-8 md:p-10 lg:col-span-5">
            <div>
              <div className="flex items-center gap-4">
                <span className="grid size-16 place-items-center rounded-full bg-lime text-2xl font-extrabold text-bg">A</span>
                <div>
                  <div className="text-xl font-bold">You&apos;ll talk to Abuzer</div>
                  <div className="font-mono text-[11px] uppercase tracking-widest text-white/50">Founder &amp; Senior Engineer</div>
                </div>
              </div>
              <p className="mt-8 text-lg leading-relaxed text-white/65">
                The senior engineer who&apos;ll scope your build. Response within 4 business hours. No commitment on the first call.
              </p>
              <div className="mt-6 flex flex-wrap gap-2">
                {["Senior engineers only", "4h response", "No commitment"].map((t) => (
                  <span key={t} className="rounded-full border border-white/15 px-3 py-1 font-mono text-[11px] text-white/70">{t}</span>
                ))}
              </div>
            </div>
            <div className="mt-10 flex flex-wrap gap-3">
              <a data-magnetic href="https://calendly.com/abuzer/30min?back=1" target="_blank" rel="noreferrer" className="btn btn-lime">
                Book a free 30-min call <Arrow />
              </a>
              <a data-magnetic href="https://wa.me/923336527366" target="_blank" rel="noreferrer" className="btn btn-ghost">
                WhatsApp
              </a>
            </div>
          </div>

          <div data-build="drag" data-label="Contact form" className="glass p-8 md:p-10 lg:col-span-7">
            {sent ? (
              <div className="flex h-full min-h-[420px] flex-col items-center justify-center text-center">
                <div className="grid size-16 place-items-center rounded-full bg-lime text-3xl text-bg">✓</div>
                <h3 className="mt-6 text-3xl font-extrabold tracking-[-0.04em]">Message received.</h3>
                <p className="mt-3 max-w-sm text-white/60">A senior engineer will respond within 4 business hours with a clear next step.</p>
                <button onClick={() => setSent(false)} className="mt-6 cursor-pointer text-sm font-bold text-lime">Send another</button>
              </div>
            ) : (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  setSent(true);
                }}
                className="grid gap-6 md:grid-cols-2"
              >
                <div className="md:col-span-2">
                  <h3 className="text-2xl font-bold tracking-[-0.03em]">Tell us what you&apos;re building</h3>
                  <p className="mt-1 text-sm text-white/50">AI product, MVP, mobile app, codebase rescue, or dedicated team.</p>
                </div>
                <input required className="field" placeholder="Your name" />
                <input required type="email" className="field" placeholder="Email address" />
                <select className="field md:col-span-2" defaultValue="">
                  <option value="" disabled>What do you need?</option>
                  <option>AI product / automation</option>
                  <option>MVP development</option>
                  <option>Web or mobile app</option>
                  <option>Code audit / rescue</option>
                  <option>Dedicated developers</option>
                  <option>QA &amp; testing</option>
                </select>
                <textarea required rows={4} className="field md:col-span-2 resize-none" placeholder="Share your project goals…" />
                <div className="flex flex-wrap items-center justify-between gap-4 md:col-span-2">
                  <span className="font-mono text-[11px] uppercase tracking-widest text-white/40">Available worldwide · remote</span>
                  <button data-magnetic type="submit" className="btn btn-lime cursor-pointer">Send message <Arrow /></button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="relative overflow-hidden border-t border-white/10 bg-bg px-5 pb-8 pt-16 md:px-10" data-name="Footer">
      <div className="mx-auto max-w-[1500px]">
        <div className="grid gap-10 md:grid-cols-4">
          <div className="md:col-span-2">
            <p className="max-w-sm text-white/55">Senior engineers shipping AI software, MVPs and mobile apps for founders around the world.</p>
          </div>
          <div className="space-y-2 text-sm text-white/60">
            <div className="font-mono text-[11px] uppercase tracking-widest text-white/35">Explore</div>
            {["Services", "Process", "Work", "FAQ"].map((l) => <div key={l}>{l}</div>)}
          </div>
          <div className="space-y-2 text-sm text-white/60">
            <div className="font-mono text-[11px] uppercase tracking-widest text-white/35">Location</div>
            <div>Available worldwide (remote)</div>
            <div>Lahore, Pakistan</div>
          </div>
        </div>
        <h2 data-build="text" data-label="Wordmark" className="mt-12 select-none text-[clamp(4rem,21vw,24rem)] font-extrabold leading-[0.8] tracking-[-0.07em]">
          <span className="w"><span className="wi">gree<span className="text-lime">logix</span></span></span>
        </h2>
        <div className="mt-10 flex flex-wrap justify-between gap-3 font-mono text-[11px] uppercase tracking-widest text-white/35">
          <span>© {new Date().getFullYear()} GreeLogix. All rights reserved.</span>
          <span>Built live by 6 collaborators ✦</span>
        </div>
      </div>
    </footer>
  );
}
