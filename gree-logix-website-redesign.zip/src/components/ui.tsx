import type { ReactNode } from "react";

/** Splits text into masked words so GSAP can "type" them in. Wrap words in *asterisks* for the serif accent. */
export function Words({ text }: { text: string }) {
  let accent = false;
  const out: ReactNode[] = [];
  text.split(" ").forEach((raw, i) => {
    let w = raw;
    if (w.startsWith("*")) {
      accent = true;
      w = w.slice(1);
    }
    const ends = w.endsWith("*");
    if (ends) w = w.slice(0, -1);
    out.push(
      <span key={`w${i}`} className="w">
        <span className={"wi" + (accent ? " acc" : "")}>{w}</span>
      </span>,
      " "
    );
    if (ends) accent = false;
  });
  return <>{out}</>;
}

const hAttr = (h?: boolean) => (h ? { "data-h": "" } : {});

export function Chip({ children, h, label = "Label" }: { children: ReactNode; h?: boolean; label?: string }) {
  return (
    <div
      data-build="draw"
      data-label={label}
      {...hAttr(h)}
      className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-[#0a100b]/80 px-3.5 py-1.5 font-mono text-[11px] uppercase tracking-[0.18em] text-white/70"
    >
      <span className="size-1.5 rounded-full bg-lime" />
      {children}
    </div>
  );
}

export function SectionHead({
  kicker,
  title,
  sub,
  h,
  center,
}: {
  kicker: string;
  title: string;
  sub?: string;
  h?: boolean;
  center?: boolean;
}) {
  return (
    <div className={center ? "mx-auto flex max-w-4xl flex-col items-center text-center" : "max-w-4xl"}>
      <Chip h={h}>{kicker}</Chip>
      <h2
        data-build="text"
        data-label="H2"
        {...hAttr(h)}
        className="mt-6 text-[clamp(2.4rem,6.4vw,6rem)] font-extrabold leading-[0.95] tracking-[-0.04em]"
      >
        <Words text={title} />
      </h2>
      {sub && (
        <p
          data-build="text"
          data-label="Paragraph"
          {...hAttr(h)}
          className="mt-6 max-w-2xl text-lg leading-relaxed text-white/60 md:text-xl"
        >
          <Words text={sub} />
        </p>
      )}
    </div>
  );
}

export function Arrow({ className = "" }: { className?: string }) {
  return (
    <svg className={className} width="16" height="16" viewBox="0 0 16 16" fill="none">
      <path d="M3 13L13 3M13 3H5M13 3v8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
