export const problems = [
  { t: "Your MVP keeps slipping", d: "You have investor pressure or market timing — but the build is stuck in scope creep, slow sprints, or a team that can't ship.", l: "MVP development", id: "mvp-development" },
  { t: "AI demos that never reach production", d: "Chatbots, automations, or AI features work in a prototype but break on real data, security, or integration requirements.", l: "AI automation services", id: "ai-automation" },
  { t: "Inherited or AI-generated code you can't trust", d: "Lovable, Cursor, or a previous vendor left you with a codebase you're afraid to put real users on.", l: "Code review & audit", id: "code-review" },
  { t: "Unclear product UX or handoff gaps", d: "Designers deliver static mockups that engineering struggles to build. Sprints stall in rework and UI states drift.", l: "Figma UI/UX design", id: "ux" },
  { t: "You need senior devs without a local hire", d: "Scaling Laravel, Flutter, React, or Node.js delivery — without recruiting, onboarding, or junior hand-offs.", l: "Hire dedicated developers", id: "hire" },
  { t: "Launch blocked by quality gaps", d: "Manual QA isn't keeping up. Regressions, security holes, or mobile edge cases show up right before go-live.", l: "Software QA testing", id: "qa" },
  { t: "A vendor failed — and the product is at risk", d: "Large teams, missed deadlines, fragile architecture. You need a senior team to stabilize and ship what others couldn't.", l: "See our rescue case study", id: "rescue" },
];

export const services = [
  { t: "AI Products & Automation", d: "Chatbots, agents, workflow automation and AI features that survive real data, real security reviews and real users.", tags: ["OpenAI", "Python", "Node.js"], h: 110 },
  { t: "MVP Development", d: "From idea to revenue-ready in 4–8 weeks. Weekly demos, senior-only team, scope tied to business outcomes.", tags: ["Laravel", "React", "Flutter"], h: 160 },
  { t: "Custom Web Apps", d: "SaaS platforms, dashboards and internal tools — architected to scale, documented to hand over.", tags: ["React", "Laravel", "PostgreSQL"], h: 200 },
  { t: "Mobile Apps", d: "Cross-platform iOS & Android builds with native-grade polish, offline support and clean release pipelines.", tags: ["Flutter", "React Native", "Firebase"], h: 280 },
  { t: "UI/UX Design", d: "Figma systems that engineers can actually build. No static-mockup drift, no rework loops.", tags: ["Figma", "Design systems", "Prototyping"], h: 320 },
  { t: "QA & Testing", d: "Manual + automated testing, regression suites, security checks and mobile edge-case coverage before go-live.", tags: ["E2E", "Security", "Regression"], h: 340 },
  { t: "Code Review & Audit", d: "We harden Lovable, Cursor, Bolt and v0 apps — secure auth, fix database leaks, and make it production-safe.", tags: ["Audit", "Hardening", "Supabase"], h: 30 },
  { t: "Dedicated Developers", d: "Senior Laravel, Flutter, React and Node.js engineers embedded in your team — without the recruiting overhead.", tags: ["Laravel", "Node.js", "Remote"], h: 60 },
];

export const steps = [
  { n: "01", t: "Discovery Call", d: "A 30-minute strategy call. We map your goals, constraints, stack and timeline — and tell you honestly if we're the right fit." },
  { n: "02", t: "Scope & Roadmap", d: "You get a clear delivery plan: milestones, tech approach, and what ships first for the highest business impact." },
  { n: "03", t: "Build in Sprints", d: "Senior engineers ship in weekly demos. AI-augmented where it helps — never at the cost of architecture or security." },
  { n: "04", t: "Launch & Support", d: "Deployment, QA sign-off, documentation and post-launch fixes. Optional ongoing development or dedicated team extension." },
];

export const portfolio = [
  { n: "Jalebi", k: "Restaurant SaaS Platform", d: "Multi-branch restaurant ops — inventory, orders, and reporting in one Laravel + React platform.", tags: ["Laravel", "React", "PostgreSQL"], c: "#7dff5c" },
  { n: "Ad Grants Pilot", k: "AI Chatbot for Nonprofits", d: "Admin panel for nonprofit ad campaigns — conversation monitoring, AI responses, and analytics.", tags: ["Node.js", "OpenAI", "React"], c: "#38e1ff" },
  { n: "Shepherd", k: "AI Tutor & Study App", d: "Flutter app with AI tutor, flashcards, quizzes, and personalized study plans for students.", tags: ["Flutter", "OpenAI", "Firebase"], c: "#a78bff" },
];

export const quotes = [
  { q: "What a 70-engineer team could not deliver, a small senior team at GreeLogix shipped. The app went from stuck to live across mobile, web, and backend.", w: "Founder", r: "EdTech platform rescue" },
  { q: "Clear communication, fast iterations, and engineers who actually understand the business logic — not just tickets.", w: "Startup founder", r: "MVP build" },
  { q: "They hardened our Lovable prototype, fixed security gaps, and got us to production in weeks instead of months.", w: "Product owner", r: "AI prototype hardening" },
];

export const deliverables = [
  { t: "Requirements Documentation", d: "Comprehensive analysis of your project requirements, user stories, and acceptance criteria." },
  { t: "System Design & Wireframes", d: "Architecture blueprints, database schemas, and interactive wireframes to visualise your solution." },
  { t: "Production Source Code", d: "Clean, well-documented, maintainable code following industry best practices and standards." },
  { t: "Comprehensive Test Cases", d: "Unit, integration and end-to-end testing for quality assurance you can verify." },
  { t: "Deployment & Support", d: "Seamless deployment to your infrastructure with documentation and ongoing support options." },
];

export const stack = [
  ["React", "Frontend"], ["React Native", "Mobile"], ["Flutter", "Mobile"], ["Node.js", "Backend"], ["Laravel", "Backend"],
  ["WordPress", "CMS"], ["Python", "AI/ML"], ["TensorFlow", "AI/ML"], ["OpenAI", "AI/ML"], ["Lovable", "Rapid Dev"],
  ["Replit", "Rapid Dev"], ["TypeScript", "Language"], ["PostgreSQL", "Database"], ["MongoDB", "Database"], ["AWS", "Cloud"],
  ["Docker", "DevOps"], ["Figma", "Design"], ["Firebase", "Backend"], ["Supabase", "Backend"],
];

export const whyPoints = [
  "150+ products shipped for US, UK, UAE & AU clients",
  "Top-rated Upwork agency · 5.0 ★ on Fiverr · Clutch verified",
  "AI automation, Laravel, Flutter, React & Node.js specialists",
  "QA, code audit & AI-generated app hardening",
  "Transparent pricing — no hidden scope creep",
  "Lahore-based team with international delivery experience",
];

export const pillars = [
  { t: "Senior Engineers Only", d: "Every project is led by experienced developers — no junior bait-and-switch, no outsourced surprises." },
  { t: "Production-First Delivery", d: "Security, QA, and architecture built in from sprint one — not bolted on before launch." },
  { t: "4-Hour Response Guarantee", d: "A senior engineer responds within 4 business hours. Direct access — not a ticket queue." },
  { t: "Outcome-Focused Sprints", d: "Weekly demos, clear milestones, and scope tied to business results — not vanity features." },
];

export const posts = [
  { c: "AI Engineering · 11 min read", t: "The AI Prototype-to-Production Hardening Checklist (2026): Taking Cursor, Lovable & Bolt Apps to Scale", d: "The exact 10-point technical checklist senior engineers use to secure auth, fix database leaks, and scale AI-generated code.", h: 130 },
  { c: "Startup & MVP · 9 min read", t: "12 Questions Every Founder Must Ask an App Development Company", d: "Ask these 12 critical engineering, pricing, and IP ownership questions to avoid delays, budget blowouts, and vendor lock-in.", h: 200 },
  { c: "Mobile Development · 8 min read", t: "How Much Does a Flutter App Cost to Build in 2026?", d: "Transparent pricing benchmarks and real timelines for Flutter cross-platform mobile development.", h: 280 },
];

export const faqs = [
  { q: "How fast can you ship an MVP?", a: "A typical MVP takes 4–8 weeks depending on scope. You see a working demo every week, so there are no surprises at the end." },
  { q: "Who will I actually work with?", a: "Senior engineers only. You talk directly to the people building your product — no junior hand-offs, no ticket queue, and a response within 4 business hours." },
  { q: "Do I own the code?", a: "Yes. 100% code ownership, full documentation, and 90 days of free support after launch." },
  { q: "Can you fix or take over an existing codebase?", a: "Absolutely. We audit and harden AI-generated apps (Lovable, Cursor, Bolt, v0) and rescue products from failed vendors — like the EdTech platform we shipped after a 70+ engineer team stalled." },
  { q: "Which technologies do you use?", a: "Laravel, Flutter, React, React Native, Node.js, Python, OpenAI, PostgreSQL, MongoDB, AWS, Docker, Firebase and Supabase — chosen for your product, not our preferences." },
  { q: "How does pricing work?", a: "Transparent, milestone-based scope with no hidden creep. Book a free 30-minute call and you'll leave with scope, timeline and a cost range — no sales deck." },
  { q: "Where are you based and who do you serve?", a: "We're a Lahore-based team working remotely with founders and operators in the US, UK, UAE, Australia, Canada and beyond." },
];
