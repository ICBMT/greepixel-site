import { gsap } from "./gsap";

export type Variant = "draw" | "drag" | "text";

const TEAM = [
  { name: "Ayesha", role: "Design", color: "#7dff5c", hx: 0.07, hy: 0.32, msgs: ["nudging 2px", "that spacing 👌", "adding auto-layout"] },
  { name: "Hamza", role: "3D", color: "#38e1ff", hx: 0.93, hy: 0.24, msgs: ["tweaking the cubes", "shaders compiling…", "more glow?"] },
  { name: "Sara", role: "QA", color: "#ff5fa8", hx: 0.05, hy: 0.78, msgs: ["tested on iOS ✓", "found an edge case", "zero regressions"] },
  { name: "Bilal", role: "Backend", color: "#ffb23e", hx: 0.95, hy: 0.72, msgs: ["deploying…", "migrations ✓", "p95 < 120ms"] },
  { name: "Zain", role: "AI", color: "#a78bff", hx: 0.62, hy: 0.9, msgs: ["prompt tuned", "evals passing", "agent online"] },
  { name: "Abuzer", role: "Founder", color: "#ffe34d", hx: 0.78, hy: 0.09, msgs: ["ship it 🚀", "LGTM", "demo on Friday"] },
];

interface Cur {
  el: HTMLDivElement;
  inner: HTMLElement;
  arrow: SVGElement;
  bubble: HTMLElement;
  color: string;
  msgs: string[];
  x: number;
  y: number;
  hx: number;
  hy: number;
  ph: number;
  follow: null | (() => { x: number; y: number });
  onArrive: null | (() => void);
  fast: boolean;
  busyUntil: number;
}

interface Job {
  el: HTMLElement;
  sel: HTMLElement;
  px: number;
  py: number;
  pad: number;
}

const now = () => gsap.globalTimeline.time();
const rand = (a: number, b: number) => a + Math.random() * (b - a);

class Builders {
  private layer: HTMLDivElement | null = null;
  private cursors: Cur[] = [];
  private jobs = new Set<Job>();
  private pending: HTMLElement[] = [];
  private started = false;
  private mounted = false;
  private tick: ((t: number, dt: number) => void) | null = null;

  mount() {
    if (this.mounted) return;
    this.mounted = true;
    this.started = false;
    this.pending = [];

    const layer = document.createElement("div");
    layer.className = "bc-layer";
    document.body.appendChild(layer);
    this.layer = layer;

    this.cursors = TEAM.map((m, i) => {
      const el = document.createElement("div");
      el.className = "bc";
      el.style.setProperty("--c", m.color);
      el.innerHTML = `
        <div class="bc-in">
          <svg class="bc-arrow" width="24" height="24" viewBox="0 0 24 24"><path d="M3 2.2l16.6 8.4-7.3 2.1-2.6 7.6z" fill="${m.color}" stroke="#050706" stroke-width="1.4" stroke-linejoin="round"/></svg>
          <span class="bc-name">${m.name}<i>${m.role}</i></span>
          <span class="bc-bubble"></span>
        </div>`;
      layer.appendChild(el);
      return {
        el,
        inner: el.querySelector(".bc-in") as HTMLElement,
        arrow: el.querySelector(".bc-arrow") as SVGElement,
        bubble: el.querySelector(".bc-bubble") as HTMLElement,
        color: m.color,
        msgs: m.msgs,
        x: i % 2 ? window.innerWidth + 80 : -80,
        y: rand(100, window.innerHeight - 100),
        hx: m.hx,
        hy: m.hy,
        ph: i * 1.7 + 0.4,
        follow: null,
        onArrive: null,
        fast: false,
        busyUntil: 0,
      } as Cur;
    });

    this.tick = (time: number, dtms: number) => this.update(time, dtms);
    gsap.ticker.add(this.tick);
  }

  destroy() {
    if (!this.mounted) return;
    this.mounted = false;
    this.started = false;
    if (this.tick) gsap.ticker.remove(this.tick);
    this.layer?.remove();
    this.layer = null;
    this.cursors = [];
    this.jobs.clear();
  }

  /** Cursors "join" the file, then flush anything that was waiting for them. */
  start() {
    if (!this.mounted || this.started) return;
    this.started = true;
    const n = now();
    this.cursors.forEach((c, i) => {
      c.busyUntil = n + 0.5 + i * 0.13;
      gsap.to(c.inner, { opacity: 1, scale: 1, duration: 0.5, delay: i * 0.14, ease: "back.out(2.5)" });
      gsap.set(c.inner, { scale: 0 });
    });
    const list = this.pending;
    this.pending = [];
    list.forEach((el) => this.build(el));
  }

  private update(time: number, dtms: number) {
    const dt = Math.min(dtms / 1000, 0.05);
    const W = window.innerWidth;
    const H = window.innerHeight;
    for (const c of this.cursors) {
      let tx: number, ty: number, speed: number;
      if (c.follow) {
        const p = c.follow();
        tx = p.x;
        ty = p.y;
        speed = c.fast ? 11 : 7.5;
      } else {
        tx = c.hx * W + Math.sin(time * 0.45 + c.ph) * W * 0.05 + Math.sin(time * 0.9 + c.ph * 2) * W * 0.02;
        ty = c.hy * H + Math.cos(time * 0.38 + c.ph * 1.3) * H * 0.07 + Math.sin(time * 0.8 + c.ph) * H * 0.02;
        speed = 1.5;
      }
      const k = 1 - Math.exp(-speed * dt);
      const vx = (tx - c.x) * k;
      const vy = (ty - c.y) * k;
      c.x += vx;
      c.y += vy;
      c.el.style.transform = `translate3d(${(c.x - 3).toFixed(1)}px,${(c.y - 2).toFixed(1)}px,0)`;
      const tilt = Math.max(-16, Math.min(16, vx * 0.5));
      c.arrow.style.rotate = `${tilt.toFixed(1)}deg`;
      if (c.onArrive && Math.hypot(tx - c.x, ty - c.y) < 12) {
        const f = c.onArrive;
        c.onArrive = null;
        f();
      }
    }
    for (const j of this.jobs) {
      const r = j.el.getBoundingClientRect();
      const p = j.pad;
      j.sel.style.transform = `translate3d(${(r.left - p).toFixed(1)}px,${(r.top - p).toFixed(1)}px,0)`;
      j.sel.style.width = `${((r.width + 2 * p) * j.px).toFixed(1)}px`;
      j.sel.style.height = `${((r.height + 2 * p) * j.py).toFixed(1)}px`;
    }
  }

  /** Called by ScrollTrigger when an element should be placed on the page. */
  build(el: HTMLElement) {
    if (!this.mounted) return;
    if (!this.started) {
      this.pending.push(el);
      return;
    }
    const variant = (el.dataset.build as Variant) || "draw";
    // Anything far outside the viewport (e.g. after a nav jump) is simply placed without a cursor trip
    const vr = el.getBoundingClientRect();
    if (vr.bottom < -80 || vr.top > window.innerHeight + 80 || vr.right < -80 || vr.left > window.innerWidth + 80) {
      this.reveal(el, variant, true);
      return;
    }
    const t = now();
    const free = this.cursors.filter((c) => c.busyUntil <= t);
    const c = free.length
      ? free[Math.floor(Math.random() * free.length)]
      : [...this.cursors].sort((a, b) => a.busyUntil - b.busyUntil)[0];
    const wait = Math.max(0, c.busyUntil - t);
    if (wait > 2.6) {
      this.reveal(el, variant, true);
      return;
    }
    c.busyUntil = t + wait + 2.0;
    gsap.delayedCall(wait, () => this.run(c, el, variant));
  }

  private moveTo(c: Cur, fn: () => { x: number; y: number }, cb: () => void, fast = false) {
    c.follow = fn;
    c.fast = fast;
    let called = false;
    const go = () => {
      if (called) return;
      called = true;
      c.onArrive = null;
      cb();
    };
    c.onArrive = go;
    gsap.delayedCall(1.3, go);
  }

  private click(c: Cur) {
    if (!this.layer) return;
    gsap.fromTo(c.inner, { scale: 1 }, { scale: 0.78, duration: 0.09, yoyo: true, repeat: 1, ease: "power2.out", overwrite: "auto" });
    const r = document.createElement("div");
    r.className = "bripple";
    r.style.setProperty("--c", c.color);
    r.style.transform = `translate3d(${c.x}px,${c.y}px,0)`;
    this.layer.appendChild(r);
    // ripple uses an inner scale via gsap on a wrapper-less element
    gsap.fromTo(
      r,
      { opacity: 0.9, scale: 0.2 },
      { opacity: 0, scale: 1.7, duration: 0.7, ease: "power2.out", onComplete: () => r.remove() }
    );
  }

  private say(c: Cur) {
    c.bubble.textContent = c.msgs[Math.floor(Math.random() * c.msgs.length)];
    gsap.killTweensOf(c.bubble);
    gsap.fromTo(c.bubble, { opacity: 0, y: 6, scale: 0.92 }, { opacity: 1, y: 0, scale: 1, duration: 0.35, ease: "back.out(2)" });
    gsap.to(c.bubble, { opacity: 0, y: -4, duration: 0.3, delay: 2.0 });
  }

  private makeSel(c: Cur) {
    const s = document.createElement("div");
    s.className = "bsel";
    s.style.setProperty("--c", c.color);
    s.innerHTML = `<i class="h tl"></i><i class="h tr"></i><i class="h bl"></i><i class="h br"></i><span class="tag"></span>`;
    this.layer?.appendChild(s);
    return s;
  }

  private run(c: Cur, el: HTMLElement, variant: Variant) {
    if (!this.mounted || !this.layer) return;
    const sel = this.makeSel(c);
    const job: Job = { el, sel, px: 0, py: 0, pad: variant === "text" ? 10 : 7 };
    this.jobs.add(job);
    if (Math.random() < 0.6) this.say(c);

    const rect = () => el.getBoundingClientRect();
    const tag = sel.querySelector(".tag") as HTMLElement;
    const label = el.dataset.label || el.tagName.toLowerCase();
    const showTag = () => {
      const r = rect();
      tag.textContent = `${label} · ${Math.round(r.width)}×${Math.round(r.height)}`;
      gsap.to(tag, { opacity: 1, duration: 0.25 });
    };
    const finish = (delay: number) => {
      gsap.delayedCall(delay, () => {
        gsap.to(sel, {
          opacity: 0,
          duration: 0.4,
          onComplete: () => {
            sel.remove();
            this.jobs.delete(job);
          },
        });
        c.follow = null;
        c.onArrive = null;
        c.fast = false;
      });
    };

    if (variant === "drag") {
      const dx = (Math.random() < 0.5 ? -1 : 1) * rand(70, 150);
      const dy = -rand(50, 120);
      gsap.set(el, { x: dx, y: dy, rotation: rand(-9, 9), opacity: 0 });
      this.moveTo(
        c,
        () => {
          const r = rect();
          return { x: r.left + 16, y: r.top + 16 };
        },
        () => {
          this.click(c);
          gsap.set(sel, { opacity: 1 });
          job.px = job.py = 1;
          window.dispatchEvent(new Event("gl:build"));
          gsap.to(el, { opacity: 1, duration: 0.25 });
          c.fast = true;
          c.follow = () => {
            const r = rect();
            return { x: r.left + 16, y: r.top + 16 };
          };
          gsap.to(el, {
            x: 0,
            y: 0,
            rotation: 0,
            duration: 1.05,
            ease: "power3.inOut",
            onComplete: () => {
              gsap.set(el, { clearProps: "transform" });
              this.click(c);
              showTag();
              finish(0.65);
            },
          });
        }
      );
      return;
    }

    // draw / text: fly to the top-left corner, click, drag-select a box, then the content is "typed in"
    this.moveTo(
      c,
      () => {
        const r = rect();
        return { x: r.left - job.pad, y: r.top - job.pad };
      },
      () => {
        this.click(c);
        gsap.set(sel, { opacity: 1 });
        c.follow = () => {
          const r = rect();
          return {
            x: r.left - job.pad + (r.width + 2 * job.pad) * job.px,
            y: r.top - job.pad + (r.height + 2 * job.pad) * job.py,
          };
        };
        c.fast = true;
        gsap.to(job, {
          px: 1,
          py: 1,
          duration: 0.6,
          ease: "power2.inOut",
          onComplete: () => {
            this.click(c);
            showTag();
            this.reveal(el, variant, false);
            finish(0.9);
          },
        });
      }
    );
  }

  /** The actual "placing" of the element. */
  reveal(el: HTMLElement, variant: Variant, quick: boolean) {
    window.dispatchEvent(new Event("gl:build"));
    if (variant === "text") {
      const words = el.querySelectorAll(".wi");
      gsap.fromTo(
        words,
        { yPercent: 110, y: 0 },
        { yPercent: 0, y: 0, duration: quick ? 0.7 : 1, stagger: quick ? 0.015 : 0.035, ease: "expo.out" }
      );
      return;
    }
    if (variant === "drag") {
      gsap.fromTo(el, { opacity: 0, y: 30 }, { opacity: 1, y: 0, duration: 0.8, ease: "expo.out", clearProps: "transform" });
      return;
    }
    gsap.fromTo(
      el,
      { opacity: 0, filter: "blur(14px)", clipPath: "inset(0% 100% 0% 0%)" },
      {
        opacity: 1,
        filter: "blur(0px)",
        clipPath: "inset(-10% -10% -10% -10%)",
        duration: quick ? 0.7 : 1,
        ease: "expo.out",
        clearProps: "filter,clipPath",
      }
    );
    const items = el.querySelectorAll("[data-item]");
    if (items.length) {
      if (el.hasAttribute("data-pop")) {
        gsap.fromTo(
          items,
          { y: -50, opacity: 0, scale: 0.6, rotation: () => rand(-12, 12) },
          { y: 0, opacity: 1, scale: 1, rotation: 0, duration: 0.9, stagger: { each: 0.04, from: "random" }, ease: "back.out(2)", delay: 0.1, clearProps: "transform" }
        );
      } else {
        gsap.fromTo(
          items,
          { y: 26, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.9, stagger: 0.09, ease: "expo.out", delay: 0.2, clearProps: "transform" }
        );
      }
    }
  }
}

export const builders = new Builders();

/** Subtle magnetic pull on buttons. */
export function initMagnetic() {
  const els = Array.from(document.querySelectorAll<HTMLElement>("[data-magnetic]"));
  const cleanups: Array<() => void> = [];
  els.forEach((el) => {
    const xTo = gsap.quickTo(el, "x", { duration: 0.6, ease: "elastic.out(1, 0.5)" });
    const yTo = gsap.quickTo(el, "y", { duration: 0.6, ease: "elastic.out(1, 0.5)" });
    const move = (e: PointerEvent) => {
      const r = el.getBoundingClientRect();
      xTo((e.clientX - (r.left + r.width / 2)) * 0.28);
      yTo((e.clientY - (r.top + r.height / 2)) * 0.28);
    };
    const leave = () => {
      xTo(0);
      yTo(0);
    };
    el.addEventListener("pointermove", move);
    el.addEventListener("pointerleave", leave);
    cleanups.push(() => {
      el.removeEventListener("pointermove", move);
      el.removeEventListener("pointerleave", leave);
    });
  });
  return () => cleanups.forEach((f) => f());
}
