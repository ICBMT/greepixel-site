import Lenis from "lenis";
import { gsap, ScrollTrigger } from "./gsap";
import { stage } from "../three/stage";

let lenis: Lenis | null = null;
let tickFn: ((t: number) => void) | null = null;

export function initScroll() {
  if (lenis) return lenis;
  // Lerp-based inertia = the soft, rubbery feel of iOS momentum scrolling
  lenis = new Lenis({
    lerp: 0.085,
    wheelMultiplier: 0.9,
    touchMultiplier: 1.5,
    smoothWheel: true,
  });
  lenis.on("scroll", (e: { velocity: number }) => {
    ScrollTrigger.update();
    stage.vel = e.velocity;
  });
  tickFn = (t: number) => lenis?.raf(t * 1000);
  gsap.ticker.add(tickFn);
  gsap.ticker.lagSmoothing(0);
  return lenis;
}

export function destroyScroll() {
  if (tickFn) gsap.ticker.remove(tickFn);
  lenis?.destroy();
  lenis = null;
  tickFn = null;
}

export function getLenis() {
  return lenis;
}

export function scrollToTarget(target: string | number) {
  if (lenis) {
    lenis.scrollTo(target, {
      duration: 1.9,
      easing: (t: number) => (t === 1 ? 1 : 1 - Math.pow(2, -10 * t)),
    });
  } else if (typeof target === "string") {
    document.querySelector(target)?.scrollIntoView({ behavior: "smooth" });
  }
}
