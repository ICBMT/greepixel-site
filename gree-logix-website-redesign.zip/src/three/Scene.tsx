import { useEffect, useRef } from "react";
import * as THREE from "three";
import { gsap } from "../lib/gsap";
import { stage } from "./stage";

const GRID = 14;
const N = GRID * GRID * GRID; // 2744 cubes

function mulberry32(a: number) {
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const VERT = /* glsl */ `
attribute vec3 aA; attribute vec3 aB; attribute vec3 aC; attribute vec3 aD; attribute vec3 aS; attribute vec4 aR;
uniform float uP; uniform float uTime; uniform float uPulse;
varying vec2 vUv; varying vec3 vN; varying float vSeed; varying float vDepth; varying vec3 vView;

float tt(float f, float r){ return smoothstep(r*0.45, 0.55 + r*0.45, clamp(f, 0., 1.)); }
mat3 rotAxis(vec3 a, float ang){
  float c = cos(ang), s = sin(ang), ic = 1. - c;
  return mat3(
    c + a.x*a.x*ic,       a.x*a.y*ic + a.z*s, a.x*a.z*ic - a.y*s,
    a.y*a.x*ic - a.z*s,   c + a.y*a.y*ic,     a.y*a.z*ic + a.x*s,
    a.z*a.x*ic + a.y*s,   a.z*a.y*ic - a.x*s, c + a.z*a.z*ic
  );
}

void main(){
  float r = aR.x;
  float t0 = tt(uP, r), t1 = tt(uP - 1., r), t2 = tt(uP - 2., r);
  vec3 pos = mix(aA, aB, t0);
  pos = mix(pos, aC, t1);
  pos = mix(pos, aD, t2);

  float bump = sin(3.14159 * t0) + sin(3.14159 * t1) + sin(3.14159 * t2);
  vec3 dir = normalize(aR.yzw * 2. - 1. + 0.001);
  pos += dir * bump * 2.4;

  vec3 sA = vec3((0.35 + aR.y * 0.65) * 0.42);
  vec3 sc = mix(sA, aS, t0);
  sc = mix(sc, vec3(0.2), t1);
  sc = mix(sc, vec3(0.27), t2);

  float ch = mix(1., 0., t0);
  ch = mix(ch, 0.12, t1);
  ch = mix(ch, 0., t2);
  ch = max(ch, min(1., bump));

  float ang = (uTime * 0.6 * (0.4 + aR.w) + aR.z * 6.2831) * ch;
  mat3 R = rotAxis(dir, ang);

  vec3 world = pos + R * (position * sc);
  world += normalize(pos + 0.001) * uPulse * 0.22 * sin(length(pos) * 2.2 - uTime * 7.);

  vec4 mv = modelViewMatrix * vec4(world, 1.);
  vUv = uv;
  vN = normalize(mat3(modelMatrix) * (R * normal));
  vSeed = aR.y;
  vDepth = -mv.z;
  vView = -mv.xyz;
  gl_Position = projectionMatrix * mv;
}
`;

const FRAG = /* glsl */ `
uniform vec3 uC1; uniform vec3 uC2; uniform float uBright; uniform float uPulse;
varying vec2 vUv; varying vec3 vN; varying float vSeed; varying float vDepth; varying vec3 vView;
void main(){
  vec2 e = min(vUv, 1. - vUv);
  float edge = min(e.x, e.y);
  float line = 1. - smoothstep(0., 0.075, edge);
  float glow = 1. - smoothstep(0., 0.28, edge);
  vec3 L = normalize(vec3(0.4, 0.8, 0.5));
  float d = dot(normalize(vN), L) * 0.5 + 0.5;
  vec3 accent = mix(uC1, uC2, smoothstep(0.55, 1., vSeed));
  float fres = pow(1. - abs(dot(normalize(vN), normalize(vView))), 2.);
  vec3 base = vec3(0.016, 0.03, 0.024) * (0.5 + d * 1.4);
  vec3 col = base + accent * (line * (0.55 + 0.7 * d) + glow * 0.07 + fres * 0.09);
  col += accent * uPulse * (line * 1.4 + 0.15);
  col *= uBright;
  float fog = smoothstep(9., 27., vDepth);
  col = mix(col, vec3(0.02, 0.027, 0.024), fog);
  gl_FragColor = vec4(col, 1.);
}
`;

export default function Scene() {
  const hostRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const host = hostRef.current!;
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
    } catch {
      return;
    }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.75));
    renderer.setClearColor(0x050706, 1);
    host.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(50, 1, 0.1, 80);

    // ---------- formations ----------
    const rnd = mulberry32(11);
    const aA = new Float32Array(N * 3);
    const aB = new Float32Array(N * 3);
    const aC = new Float32Array(N * 3);
    const aD = new Float32Array(N * 3);
    const aS = new Float32Array(N * 3);
    const aR = new Float32Array(N * 4);

    const COLS = 56;
    const ROWS = N / COLS; // 49
    for (let i = 0; i < N; i++) {
      // A — loose shell of floating cubes around the core
      const rad = 3.4 + Math.pow(rnd(), 0.7) * 5;
      const th = rnd() * Math.PI * 2;
      const ph = Math.acos(2 * rnd() - 1);
      aA[i * 3] = rad * Math.sin(ph) * Math.cos(th) * 1.25;
      aA[i * 3 + 1] = rad * Math.cos(ph) * 0.8;
      aA[i * 3 + 2] = rad * Math.sin(ph) * Math.sin(th);

      // B — a skyline / city being built
      const ix = i % COLS;
      const iz = Math.floor(i / COLS);
      const n = Math.sin(ix * 0.34) + Math.sin(iz * 0.29) + Math.sin((ix + iz) * 0.17) + rnd() * 1.1;
      const dist = Math.hypot(ix - COLS / 2, (iz - ROWS / 2) * 1.2) / 30;
      const h = 0.1 + Math.pow(Math.max(0, (n + 2) / 5.6), 2.3) * 4.4 * (1.1 - Math.min(dist, 1) * 0.55);
      aB[i * 3] = (ix - COLS / 2 + 0.5) * 0.32;
      aB[i * 3 + 1] = -2.6 + h / 2;
      aB[i * 3 + 2] = (iz - ROWS / 2 + 0.5) * 0.32;
      aS[i * 3] = 0.21;
      aS[i * 3 + 1] = h;
      aS[i * 3 + 2] = 0.21;

      // C — a torus knot of code
      const t = (i / N) * Math.PI * 2;
      const kr = Math.cos(3 * t) + 2;
      const jr = 0.42 * Math.pow(rnd(), 0.5);
      const ja = rnd() * Math.PI * 2;
      const jb = Math.acos(2 * rnd() - 1);
      aC[i * 3] = kr * Math.cos(2 * t) * 1.45 + jr * Math.sin(jb) * Math.cos(ja);
      aC[i * 3 + 1] = kr * Math.sin(2 * t) * 1.45 + jr * Math.sin(jb) * Math.sin(ja);
      aC[i * 3 + 2] = -Math.sin(3 * t) * 1.45 + jr * Math.cos(jb);

      // D — the finished product: a lattice cube
      const lx = i % GRID;
      const ly = Math.floor(i / GRID) % GRID;
      const lz = Math.floor(i / (GRID * GRID));
      aD[i * 3] = (lx - GRID / 2 + 0.5) * 0.36;
      aD[i * 3 + 1] = (ly - GRID / 2 + 0.5) * 0.36;
      aD[i * 3 + 2] = (lz - GRID / 2 + 0.5) * 0.36;

      aR[i * 4] = rnd();
      aR[i * 4 + 1] = rnd();
      aR[i * 4 + 2] = rnd();
      aR[i * 4 + 3] = rnd();
    }

    const base = new THREE.BoxGeometry(1, 1, 1);
    const geo = new THREE.InstancedBufferGeometry();
    geo.index = base.index;
    geo.setAttribute("position", base.getAttribute("position"));
    geo.setAttribute("normal", base.getAttribute("normal"));
    geo.setAttribute("uv", base.getAttribute("uv"));
    geo.setAttribute("aA", new THREE.InstancedBufferAttribute(aA, 3));
    geo.setAttribute("aB", new THREE.InstancedBufferAttribute(aB, 3));
    geo.setAttribute("aC", new THREE.InstancedBufferAttribute(aC, 3));
    geo.setAttribute("aD", new THREE.InstancedBufferAttribute(aD, 3));
    geo.setAttribute("aS", new THREE.InstancedBufferAttribute(aS, 3));
    geo.setAttribute("aR", new THREE.InstancedBufferAttribute(aR, 4));
    geo.instanceCount = N;

    const mat = new THREE.ShaderMaterial({
      vertexShader: VERT,
      fragmentShader: FRAG,
      uniforms: {
        uP: { value: 0 },
        uTime: { value: 0 },
        uPulse: { value: 0 },
        uBright: { value: 1 },
        uC1: { value: new THREE.Vector3(0.49, 1.0, 0.36) },
        uC2: { value: new THREE.Vector3(0.22, 0.88, 1.0) },
      },
    });
    const cubes = new THREE.Mesh(geo, mat);
    cubes.frustumCulled = false;
    const group = new THREE.Group();
    group.add(cubes);
    scene.add(group);

    // ---------- hero core ----------
    const core = new THREE.Group();
    const wireMat = new THREE.LineBasicMaterial({ color: 0x7dff5c, transparent: true, opacity: 0.95 });
    const ico1 = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.IcosahedronGeometry(1.7, 1)), wireMat);
    const wire2Mat = new THREE.LineBasicMaterial({ color: 0x38e1ff, transparent: true, opacity: 0.28 });
    const ico2 = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.IcosahedronGeometry(2.55, 2)), wire2Mat);
    const innerMat = new THREE.MeshBasicMaterial({ color: 0x7dff5c, transparent: true, opacity: 0.1, blending: THREE.AdditiveBlending, depthWrite: false });
    const inner = new THREE.Mesh(new THREE.IcosahedronGeometry(1.35, 3), innerMat);
    core.add(ico1, ico2, inner);

    const cv = document.createElement("canvas");
    cv.width = cv.height = 256;
    const cx = cv.getContext("2d")!;
    const gr = cx.createRadialGradient(128, 128, 0, 128, 128, 128);
    gr.addColorStop(0, "rgba(125,255,92,0.55)");
    gr.addColorStop(0.4, "rgba(125,255,92,0.12)");
    gr.addColorStop(1, "rgba(125,255,92,0)");
    cx.fillStyle = gr;
    cx.fillRect(0, 0, 256, 256);
    const glowTex = new THREE.CanvasTexture(cv);
    const glowMat = new THREE.SpriteMaterial({ map: glowTex, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false });
    const glow = new THREE.Sprite(glowMat);
    glow.scale.setScalar(11);
    core.add(glow);
    scene.add(core);

    // ---------- dust ----------
    const dustN = 900;
    const dp = new Float32Array(dustN * 3);
    for (let i = 0; i < dustN; i++) {
      const r = 10 + rnd() * 16;
      const th = rnd() * Math.PI * 2;
      const ph = Math.acos(2 * rnd() - 1);
      dp[i * 3] = r * Math.sin(ph) * Math.cos(th);
      dp[i * 3 + 1] = r * Math.cos(ph);
      dp[i * 3 + 2] = r * Math.sin(ph) * Math.sin(th);
    }
    const dustGeo = new THREE.BufferGeometry();
    dustGeo.setAttribute("position", new THREE.BufferAttribute(dp, 3));
    const dustMat = new THREE.PointsMaterial({ color: 0x9affb0, size: 0.045, transparent: true, opacity: 0.55, sizeAttenuation: true, depthWrite: false });
    const dust = new THREE.Points(dustGeo, dustMat);
    scene.add(dust);

    // ---------- interaction / loop ----------
    const cur = { ...stage };
    let mx = 0,
      my = 0,
      tmx = 0,
      tmy = 0,
      pulse = 0,
      vel = 0;
    const onMove = (e: PointerEvent) => {
      tmx = (e.clientX / window.innerWidth) * 2 - 1;
      tmy = (e.clientY / window.innerHeight) * 2 - 1;
    };
    const onBuild = () => {
      pulse = Math.min(1, pulse + 0.7);
    };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("gl:build", onBuild);

    let aspect = 1;
    const resize = () => {
      const w = window.innerWidth;
      const h = window.innerHeight;
      renderer.setSize(w, h);
      aspect = w / h;
      camera.aspect = aspect;
      camera.updateProjectionMatrix();
    };
    resize();
    window.addEventListener("resize", resize);

    const start = performance.now();
    let last = start;
    const render = () => {
      const t = (performance.now() - start) / 1000;
      const dt = Math.min((performance.now() - last) / 1000, 0.05);
      last = performance.now();
      const k = 1 - Math.exp(-dt * 4.5);
      (Object.keys(cur) as Array<keyof typeof cur>).forEach((key) => {
        if (key === "vel") return;
        cur[key] += (stage[key] - cur[key]) * k;
      });
      mx += (tmx - mx) * 0.05;
      my += (tmy - my) * 0.05;
      vel += (stage.vel - vel) * 0.1;
      pulse *= 0.93;

      mat.uniforms.uP.value = cur.p;
      mat.uniforms.uTime.value = t;
      mat.uniforms.uBright.value = cur.bright;
      mat.uniforms.uPulse.value = pulse;

      const af = aspect < 1.1 ? 1 + (1.1 - aspect) * 0.9 : 1;
      camera.fov = 50 + Math.min(Math.abs(vel) * 0.14, 16);
      camera.updateProjectionMatrix();
      camera.position.set(cur.camX + mx * 0.5, cur.camY - my * 0.35, cur.camZ * af);
      camera.lookAt(0, cur.lookY, 0);

      group.rotation.y = cur.rotY + t * 0.045 + mx * 0.25;
      group.rotation.x = my * 0.08;

      const cs = Math.max(0, cur.core);
      core.visible = cs > 0.01;
      core.scale.setScalar(cs * (1 + pulse * 0.12));
      core.rotation.y = t * 0.25 + mx * 0.3;
      core.rotation.x = t * 0.12 + my * 0.2;
      ico2.rotation.y = -t * 0.35;
      ico2.rotation.z = t * 0.1;
      wireMat.opacity = 0.7 + pulse * 0.3;
      glowMat.opacity = 0.55 + Math.sin(t * 1.4) * 0.12 + pulse * 0.3;

      dust.rotation.y = t * 0.012 - vel * 0.002;
      dust.position.y = -vel * 0.01;

      renderer.render(scene, camera);
    };
    gsap.ticker.add(render);

    return () => {
      gsap.ticker.remove(render);
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("gl:build", onBuild);
      window.removeEventListener("resize", resize);
      geo.dispose();
      base.dispose();
      mat.dispose();
      dustGeo.dispose();
      dustMat.dispose();
      glowTex.dispose();
      glowMat.dispose();
      wireMat.dispose();
      wire2Mat.dispose();
      innerMat.dispose();
      renderer.dispose();
      renderer.domElement.remove();
    };
  }, []);

  return <div ref={hostRef} className="fixed inset-0 z-0" aria-hidden="true" />;
}
