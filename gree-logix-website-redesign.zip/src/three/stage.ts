export interface Stage {
  p: number; // morph progress between 4 cube formations (0..3)
  camX: number;
  camY: number;
  camZ: number;
  lookY: number;
  rotY: number;
  bright: number;
  core: number; // hero core scale
}

export const STAGES: Record<string, Stage> = {
  hero: { p: 0, camX: 0, camY: 0.4, camZ: 11, lookY: 0, rotY: 0, bright: 1, core: 1 },
  problems: { p: 0, camX: 0, camY: 1, camZ: 15, lookY: 0, rotY: 1.5, bright: 0.38, core: 0 },
  services: { p: 1, camX: 0, camY: 6.5, camZ: 13, lookY: -1.5, rotY: 0.5, bright: 0.55, core: 0 },
  process: { p: 2, camX: 0, camY: 0, camZ: 11, lookY: 0, rotY: 0.2, bright: 0.55, core: 0 },
  work: { p: 2, camX: 0, camY: 0.6, camZ: 14, lookY: 0, rotY: 2.6, bright: 0.32, core: 0 },
  stack: { p: 3, camX: 0, camY: 0.5, camZ: 10, lookY: 0, rotY: 0.9, bright: 0.75, core: 0 },
  why: { p: 3, camX: 0, camY: 1, camZ: 14, lookY: 0, rotY: 2.2, bright: 0.38, core: 0 },
  contact: { p: 3, camX: 0, camY: 0.2, camZ: 8, lookY: 0, rotY: 3.4, bright: 0.9, core: 0 },
};

export const stage: Stage & { vel: number } = { ...STAGES.hero, vel: 0 };
